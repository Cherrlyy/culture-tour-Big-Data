library(readr)
library(dplyr)
library(readxl)
library(factoextra)

#엑셀 읽기 함수
read.any <- function(text, sep = "", ...) {
  encoding <- as.character(guess_encoding(text)[1,1])
  setting <- as.character(tools::file_ext(text))
  if(sep != "" | !(setting  %in% c("csv", "txt")) ) setting <- "custom"
  separate <- list(csv = ",", txt = "\n", custom = sep)
  result <- read.table(text, sep = separate[[setting]], fileEncoding = encoding, ...)
  return(result)
}

#백신 접종률 데이터
df_vaccine = read.any("0704인구수대비접종률데이터.csv", header=T)
df_vaccine = df_vaccine[, c(3, 4)]
df_vaccine

#정규화
normalize <- function(x){
  return((x-min(x)) / (max(x) - min(x)))
}
df_vaccine$총인구수 = normalize(df_vaccine$총인구수)
df_vaccine

corona = read.any("0704인구수대비코로나감염률데이터.csv", header = T)
corona = corona %>% select(-X) %>% filter(!(행정기관 == '전국'))
corona

v2_group = read.any("df_immunisation - df_immunisation.csv", header=T)
nw = v2_group %>% select(-X) %>% group_by(유입대상지역) %>% summarise(sum(유입인구))
colnames(nw) = c("행정기관", "유입인구")
nw

#newData = 행정기관, 감염자수, 총인구수, 감염률, 유입인구
newData = merge(corona, nw)
newData

#유입인원과 확진자수의 상관관계 파악
cor.test(newData$"감염률", newData$"유입인구")
#p-value = 0.144, cor = 0.3697855이므로 확진자수에 대하여 유입인원은 선형적인 관계가 없음

# 화장실 수 데이터
toilet = read.any("시도별공공화장실수.csv", header = T)
toilet = toilet %>% select(-X)

#유동인구 데이터
유동인구 = read.any("df_total_immunisation - df_total_immunisation.csv", header=T)
유동인구 = 유동인구[,-c(1,3)]
names(유동인구)[1] = "행정기관"
toilet = left_join(toilet, 유동인구, by="행정기관")
toilet$인당화장실 = toilet$화장실수/toilet$유동인구
toilet = toilet[,-c(2,3)]

immun = read.any("df_total_immunisation.csv", header = T)
nw = immun %>% select(-X)
colnames(nw) = c("행정기관", "접종률")

#newData = 행정기관, 감염자수, 총인구수, 감염률, 유입인구, 인당화장실
newData = merge(newData, toilet)

#newData = 행정기관, 감염자수, 총인구수, 감염률, 유입인구, 인당화장실, 접종률
newData = merge(newData, nw)

#분류를 위한 열 선별 및 정규화
new = newData %>% select(행정기관, 감염률, 인당화장실, 접종률)
new$인당화장실 = as.numeric(new$인당화장실)
new$인당화장실 = normalize(new$인당화장실)
new

#안전한 지역
dat = new %>% select(행정기관, 감염률, 인당화장실, 접종률)
dat = dat %>% filter(new$감염률 < mean(new$감염률) & new$인당화장실 > mean(new$인당화장실) & new$접종률 > mean(new$접종률))

mean = data.frame(행정기관="전국평균", 감염률=mean(new$감염률), 인당화장실=mean(new$인당화장실), 접종률=mean(new$접종률))
rbind(dat, mean)